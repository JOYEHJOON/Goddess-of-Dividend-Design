export default function Page() {
  return (
    <main style={{maxWidth:900, margin:'32px auto', padding:'16px'}}>
      <h1 style={{fontSize:24, fontWeight:700}}>Haewon · Ozna Dashboard (Secure + b64/ZIP ingest)</h1>
      <p>Use <code>/api/ingest</code> with <code>Content-Type: application/base64</code> to upload .b64 directly.</p>
    </main>
  )
}
