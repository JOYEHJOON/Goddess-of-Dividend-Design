import type { NextRequest } from 'next/server'
import crypto from 'node:crypto'
import { admin } from './supabase'

function parseCsvList(v?: string | null): string[] {
  return (v||'').split(',').map(s=>s.trim()).filter(Boolean)
}

export function clientIp(req: NextRequest): string {
  const h = req.headers
  const fwd = h.get('x-forwarded-for')
  if (fwd) return fwd.split(',')[0].trim()
  return (h.get('x-real-ip') || '0.0.0.0')
}

export function checkIpWhitelist(req: NextRequest): { ok: boolean, reason?: string } {
  const allowed = parseCsvList(process.env.ALLOWED_IPS)
  if (!allowed.length) return { ok: false, reason: 'No whitelist configured' }
  const ip = clientIp(req)
  const ok = allowed.includes(ip)
  return ok ? { ok } : { ok, reason: `IP ${ip} not allowed` }
}

function parseDate(s?: string | null): Date | null {
  if (!s) return null
  const d = new Date(s)
  return isNaN(d.getTime()) ? null : d
}

function isExpired(issuedAt: string | null, expiryDays: number): boolean {
  const d = parseDate(issuedAt)
  if (!d) return false
  const now = new Date()
  const diffMs = now.getTime() - d.getTime()
  const days = diffMs / 86400000
  return days > expiryDays
}

export function checkToken(headerToken: string | null, kind: 'INGEST' | 'ADMIN') {
  const main = process.env[`${kind}_TOKEN`]
  const issued = process.env[`${kind}_TOKEN_ISSUED_AT`]
  const prev = process.env[`${kind}_TOKEN_PREV`]
  const expiryDays = parseInt(process.env.TOKEN_EXPIRY_DAYS||'0', 10) || 0
  const rolloverDays = parseInt(process.env.TOKEN_ROLLOVER_DAYS||'0', 10) || 0

  if (!main) return { ok:false, status:500, reason:'Token not set' }
  if (!headerToken) return { ok:false, status:401, reason:'Missing token' }

  if (headerToken === main) {
    if (expiryDays && isExpired(issued||null, expiryDays)) {
      return { ok:false, status:401, reason:'Token expired' }
    }
    return { ok:true }
  }

  if (prev && headerToken === prev) {
    if (rolloverDays && isExpired(issued||null, expiryDays + rolloverDays)) {
      return { ok:false, status:401, reason:'Previous token expired' }
    }
    return { ok:true, note:'Using previous token' }
  }

  return { ok:false, status:401, reason:'Invalid token' }
}

export async function logSecure(req: NextRequest, status: number, note?: string) {
  try {
    const key = process.env.LOG_ENCRYPT_KEY
    const ip = clientIp(req)
    const path = new URL(req.url).pathname
    const payload = JSON.stringify({ ts: new Date().toISOString(), ip, path, status, note })
    if (!key || key.length < 32) return
    const iv = crypto.randomBytes(12)
    const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(key).slice(0,32), iv)
    const enc = Buffer.concat([cipher.update(payload, 'utf8'), cipher.final()])
    const tag = cipher.getAuthTag()
    const db = admin()
    if (db) {
      await db.from('sec_logs').insert({
        ts: new Date().toISOString(),
        ip, path, status,
        enc: { iv: iv.toString('base64'), tag: tag.toString('base64'), data: enc.toString('base64') },
        note: note || null
      })
    }
  } catch (e) {}
}

export function checkOrigin(req: NextRequest): { ok: boolean, reason?: string } {
  const allowed = parseCsvList(process.env.ALLOWED_ORIGINS)
  if (!allowed.length) return { ok: true }
  const origin = req.headers.get('origin') || ''
  if (!origin) return { ok:false, reason:'No Origin' }
  const ok = allowed.some(a => a === origin)
  return ok ? { ok } : { ok:false, reason:`Origin ${origin} not allowed` }
}
