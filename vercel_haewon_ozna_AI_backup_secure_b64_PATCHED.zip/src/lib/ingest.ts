import JSZip from 'jszip'
import { parse } from 'csv-parse/sync'

export async function parseBase64Payload(b64: string): Promise<any[]> {
  const buf = Buffer.from(b64, 'base64')
  // ZIP signature check: PK\x03\x04
  const isZip = buf.length >= 4 && buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04
  if (isZip) {
    const zip = await JSZip.loadAsync(buf)
    // Prefer CSV, then JSON
    const entries = Object.keys(zip.files)
    const csvNames = entries.filter(n => n.toLowerCase().endswith('.csv'))
    const jsonNames = entries.filter(n => n.toLowerCase().endswith('.json'))
    if (csvNames.length) {
      const text = await zip.files[csvNames[0]].async('string')
      return parse(text, { columns: true, skip_empty_lines: true, trim: true })
    }
    if (jsonNames.length) {
      const text = await zip.files[jsonNames[0]].async('string')
      const data = JSON.parse(text)
      return Array.isArray(data) ? data : [data]
    }
    // Fallback: read first file as text and try CSV
    const text = await zip.files[entries[0]].async('string')
    try {
      return parse(text, { columns: true, skip_empty_lines: true, trim: true })
    } catch {
      try { const j = JSON.parse(text); return Array.isArray(j)? j:[j] } catch { return [] }
    }
  } else {
    // Not zip: interpret as UTF-8 text
    const text = buf.toString('utf8')
    try {
      return parse(text, { columns: true, skip_empty_lines: true, trim: true })
    } catch {
      try { const j = JSON.parse(text); return Array.isArray(j)? j:[j] } catch { return [] }
    }
  }
}
