import { createClient } from '@supabase/supabase-js'
export function admin() {
  const url = process.env.SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE
  if (!url || !key) return null
  return createClient(url, key, { auth: { persistSession: false } })
}
export function anon() {
  const url = process.env.SUPABASE_URL
  const key = process.env.SUPABASE_ANON
  if (!url || !key) return null
  return createClient(url, key, { auth: { persistSession: false } })
}
